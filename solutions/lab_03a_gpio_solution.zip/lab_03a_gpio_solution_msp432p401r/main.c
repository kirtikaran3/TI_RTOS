// ----------------------------------------------------------------------------
// main.c  (for lab_03a_gpio project) (MSP432 Launchpad)
// ----------------------------------------------------------------------------

//***** Header Files **********************************************************
#include <stdint.h>                                                             // Standard include file
#include <driverlib.h>                                                          // DriverLib include file


//***** Prototypes ************************************************************


//***** Defines ***************************************************************
#define ONE_SECOND  600000                                                      // Well, it's about a second
#define HALF_SECOND ONE_SECOND/2


//***** Global Variables ******************************************************


//*****************************************************************************
// Main
//*****************************************************************************
void main (void)
{
    // Stop watchdog timer
    MAP_WDT_A_holdTimer();

    // Set pin P1.0 to output direction and turn LED off
    MAP_GPIO_setAsOutputPin( GPIO_PORT_P1, GPIO_PIN0 );                         // Red LED (LED1)
    MAP_GPIO_setOutputLowOnPin( GPIO_PORT_P1, GPIO_PIN0 );

    while(1) {
        // Turn on LED
        MAP_GPIO_setOutputHighOnPin( GPIO_PORT_P1, GPIO_PIN0 );

        // Wait about a second
        __delay_cycles( ONE_SECOND );

        // Turn off LED
        MAP_GPIO_setOutputLowOnPin( GPIO_PORT_P1, GPIO_PIN0 );

        // Wait another second
        __delay_cycles( ONE_SECOND );
    }
}
