// ----------------------------------------------------------------------------
// myFlash.c  (MSP432 Launchpad)
//
// These functions functions provide convenience by adding additional capability
// over the DriverLib functions
//
//    myFlash_write( );
//    myFlash_getSectorInfo( );
//    myFlash_setWaitStates( );
//
// Admittedly, this function could be optimized a little bit.
// ----------------------------------------------------------------------------

//***** Header Files **********************************************************
#include <stdint.h>                                                             // Standard include file
#include <driverlib.h>                                                          // DriverLib include file
#include "myClocks.h"                                                           // Included for crystal frequency #defines
#include "myFlash.h"


//*****************************************************************************
// myFlash_write
//
// Return:  Function exited OK (1) or failed (0)
// Inputs:  1. Pointer to the value to be written
//          2. Location in flash to be written to
//          3. # of bytes to write into flash
//
// Function first verifies that the flash waitstates are set correctly, then
// erases the flash sector and then finally writes the specified value
//*****************************************************************************
bool myFlash_write( uint32_t *value, uint32_t *flashLocation, uint32_t length )
//bool myFlash_writeS( struct myFlash_WriteInfo Info )
{
    //*************************************************************************
    // Initialization code
    //*************************************************************************
	bool EraseStatus;                                                           // Holds return value from erase function
	bool IsProtected;                                                           // Variable holds protection status
	struct myFlash_SectorInfo Info;                                             // Sector info returned from myFlash_getSectorInfo()
	uint32_t ret;                                                               // Status of this function; to be returned to calling function

	ret = 0;                                                                    // Initialize return as failure (0)

	ret = myFlash_getSectorInfo( (uint32_t) flashLocation, &Info );             // Returns bank/sector info from the specified flash address
	if ( !ret )                                                                 // If myFlash_getSectorInfo() fails (possibly due passing a bad flash address)
		goto Exit_write;                                                        // jump to the end of the function

	myFlash_setWaitStates();                                                    // Make sure flash waitstates are set correctly

    //*************************************************************************
    // Turn off flash sector's protection (if it's ON)
    //*************************************************************************
	IsProtected = MAP_FlashCtl_isSectorProtected( Info.bank, Info.sector );     // Is sector protected? Save to variable for use later on
                                                     	 	 	 	 	 	    // Bank/Sector values determined by earlier function call
	if ( IsProtected )                                                          // If sector is protected, turn off protection
		MAP_FlashCtl_unprotectSector( Info.bank, Info.sector );

    //*************************************************************************
	// Erase Sector - Keep redoing erase until it works correctly
	//              - This function hangs if erase fails; it could be by
	//                adding a timeout capability
    //*************************************************************************
	do
	{
		EraseStatus = MAP_FlashCtl_eraseSector( Info.address );                 // Info.address represents the starting address of the flash sector
	}   while ( EraseStatus == false );

    //*************************************************************************
	// Flash Write  - Set 'ret' to value returned from DriverLib function
    //*************************************************************************
	ret = MAP_FlashCtl_programMemory(
									  (uint32_t*) value,                        // Value to be written
									  (uint32_t*) flashLocation,                // Location we're writing to in flash
									  length                                    // Number of bytes to write
		  );

    //*************************************************************************
    // Turn on flash sector's protection (if it was originally ON)
    //*************************************************************************
	if ( IsProtected )
		MAP_FlashCtl_protectSector( Info.bank, Info.sector );

    //*************************************************************************
    // Return whether the write worked correctly or failed
    //*************************************************************************
Exit_write:
	return ( ret );
}

//*****************************************************************************
// myFlash_setWaitStates
//
// Return:  Number of waitstates set by function
//
// Function first gets MCLK value, then sets the flash's waitstates accordingly
//*****************************************************************************
uint32_t myFlash_setWaitStates()
{
    //*************************************************************************
    // Initialization code
    //*************************************************************************
	uint32_t waits     = 0;
	uint32_t myMCLK    = 0;

    //*************************************************************************
    // Obtain MCLK Frequency
    //*************************************************************************
	MAP_CS_setExternalClockSourceFrequency(                                         // Tell driverlib the crystal's frequencies
            LFXT_CRYSTAL_FREQUENCY_IN_HZ,
            HFXT_CRYSTAL_FREQUENCY_IN_HZ
    );

    myMCLK   = MAP_CS_getMCLK();                                                    // Get MCLK speed using driverlib function

    //*************************************************************************
    // Calculate and set waitstate values
    //*************************************************************************
    if ( myMCLK > 24000000 )                                                    // Set waitstate count based on MCLK freq
		waits = 2;
    else if ( myMCLK > 12000000 )
		waits = 1;

    MAP_FlashCtl_setWaitState( FLASH_BANK0, waits );                            // We set waitstates for both banks of flash
    MAP_FlashCtl_setWaitState( FLASH_BANK1, waits );

    //*************************************************************************
    // Return the number of waits
    //*************************************************************************
    return ( waits );
}


//*****************************************************************************
// myFlash_getSectorInfo
//
// Return:  Function exited OK (true) or failed (false)
// Inputs:  1. Address to be written in flash
//          2. Structure to be returned that holds bank, sector, and sector start address
//
// The function first shifts off the lower address to create the sector start address
// then checks to see if the address is in Flash Bank 0 or 1 (or is too large).
//*****************************************************************************
bool myFlash_getSectorInfo( uint32_t Address, struct myFlash_SectorInfo *Info )
{
    bool     ret = true;                                                        // Return value from this function
    uint32_t addr;                                                              // Local, truncated version of address passed to function
    uint32_t bank;                                                              // Intermediate bank value
    uint32_t sect;                                                              // Intermediate sector value

    addr = Address >> 12;                                                       // Shift off lower address bits
    Info->address = addr << 12;                                                 // Set sector address into Info structure

    if ( addr > 63 )                                                            // If upper address bits are > 63, the address is not in within the flash
    {
    	ret = false;
    }
    else if ( addr > 31 )                                                       // If upper address bits are > 31, the address is in flash bank 1
    {
    	bank   = 1;                                                             // Middle address bits count up from 0 to 63; for bank 1, we just need to
    	sect = addr - 32;                                                       //  subtract 32 to calculate the sector number
    }
    else
    {
    	bank = 0;                                                               // If we got here, then the address must be in bank 0
    	sect = addr;                                                            // In bank 0, the middle address value equals the sector number
    }

    if ( ret )                                                                  // Unless there's an error, we need to look up the bank & sector values
    {
    	switch ( bank )                                                         // The bank values are 0 or 1, but we set them to the DriverLib #define
    	{                                                                       // values just-in-case the are changed in future library revisions
    	case 0 :  Info->bank = FLASH_MAIN_MEMORY_SPACE_BANK0; break;
    	case 1 :  Info->bank = FLASH_MAIN_MEMORY_SPACE_BANK1; break;
    	default:  ret = false;
    	}

    	switch ( sect )                                                         // The sector values do not equate to the integer values (from 0-31)
    	{                                                                       // therefore, we must set them equal to the DriverLib #define values
    	case 0 :  Info->sector = FLASH_SECTOR0; break;
    	case 1 :  Info->sector = FLASH_SECTOR1; break;
    	case 2 :  Info->sector = FLASH_SECTOR2; break;
    	case 3 :  Info->sector = FLASH_SECTOR3; break;
    	case 4 :  Info->sector = FLASH_SECTOR4; break;
    	case 5 :  Info->sector = FLASH_SECTOR5; break;
    	case 6 :  Info->sector = FLASH_SECTOR6; break;
    	case 7 :  Info->sector = FLASH_SECTOR7; break;
    	case 8 :  Info->sector = FLASH_SECTOR8; break;
    	case 9 :  Info->sector = FLASH_SECTOR9; break;
    	case 10 :  Info->sector = FLASH_SECTOR10; break;
    	case 11 :  Info->sector = FLASH_SECTOR11; break;
    	case 12 :  Info->sector = FLASH_SECTOR12; break;
    	case 13 :  Info->sector = FLASH_SECTOR13; break;
    	case 14 :  Info->sector = FLASH_SECTOR14; break;
    	case 15 :  Info->sector = FLASH_SECTOR15; break;
    	case 16 :  Info->sector = FLASH_SECTOR16; break;
    	case 17 :  Info->sector = FLASH_SECTOR17; break;
    	case 18 :  Info->sector = FLASH_SECTOR18; break;
    	case 19 :  Info->sector = FLASH_SECTOR19; break;
    	case 20 :  Info->sector = FLASH_SECTOR20; break;
    	case 21 :  Info->sector = FLASH_SECTOR21; break;
    	case 22 :  Info->sector = FLASH_SECTOR22; break;
    	case 23 :  Info->sector = FLASH_SECTOR23; break;
    	case 24 :  Info->sector = FLASH_SECTOR24; break;
    	case 25 :  Info->sector = FLASH_SECTOR25; break;
    	case 26 :  Info->sector = FLASH_SECTOR26; break;
    	case 27 :  Info->sector = FLASH_SECTOR27; break;
    	case 28 :  Info->sector = FLASH_SECTOR28; break;
    	case 29 :  Info->sector = FLASH_SECTOR29; break;
    	case 30 :  Info->sector = FLASH_SECTOR30; break;
    	case 31 :  Info->sector = FLASH_SECTOR31; break;
    	default :  ret = false;
    	}
    }
    return ( ret );                                                             // Return whether the function was successful or not
}

