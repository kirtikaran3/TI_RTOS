/*
 * myFlash.h
 *
 */

#ifndef MYFLASH_H_
#define MYFLASH_H_

//*****************************************************************************
// "myFlash_SectorInfo" structure type definition
//
// This structure is used by myFlash_getSectorInfo() function. The user must
// create and instance of the structure and pass it by reference (i.e. by pointer)
// to the function. Given a flash address, the function returns the sectors
// base address, driverlib bank value, and driverlib sector number
//*****************************************************************************
struct myFlash_SectorInfo
{
	uint32_t address;
	uint32_t bank;
	uint32_t sector;
};

//***** Prototypes ************************************************************
bool myFlash_write( uint32_t *, uint32_t *, uint32_t );
bool myFlash_getSectorInfo( uint32_t, struct myFlash_SectorInfo * );
uint32_t myFlash_setWaitStates();


#endif /* MYFLASH_H_ */
