// ----------------------------------------------------------------------------
// main.c  (for lab_05a_buttonInterrupt project) (MSP432 Launchpad)
// ----------------------------------------------------------------------------

//***** Header Files **********************************************************
#include <stdint.h>                                                             // Standard include file
#include <driverlib.h>                                                          // DriverLib include file
#include "myGpio.h"


//***** Prototypes ************************************************************


//***** Defines ***************************************************************


//***** Global Variables ******************************************************


//*****************************************************************************
// Main
//*****************************************************************************
void main (void)
{
    // Stop watchdog timer
    MAP_WDT_A_holdTimer();

    // Disable interrupts (enabled by default on ARM Cortex-M processors) (set PRIMASK = 1) (Note that we show two different methods for accomplishing this)
    //__disable_irq();                                                          // Compiler and CMSIS intrinsic
    MAP_Interrupt_disableMaster();                                                  // DriverLib function

    // Initialize GPIO
    initGPIO();

    // Clear and enable individual IRQ interrupts (set appropriate bits in NVIC->IPR and NVIC->IER) (Note that we show two different methods for accomplishing this)
	//NVIC_ClearPendingIRQ ( PORT1_IRQn );                                      // (CMSIS) Clear pending bit for Port1 IRQ
    //NVIC_EnableIRQ( PORT1_IRQn );                                             // (CMSIS) Enable NVIC for individual Port1 IRQ
	Interrupt_unpendInterrupt ( INT_PORT1 );                                    // (DriverLib) Clear pending bit for Port1 IRQ
    MAP_Interrupt_enableInterrupt( INT_PORT1 );                                     // (DriverLib) Enable NVIC for individual Port1 IRQ

    // Enable interrupts globally (set PRIMASK = 0)
    //__enable_irq();                                                           // Compiler and CMSIS intrinsic
    MAP_Interrupt_enableMaster();                                                   // DriverLib function


    while(1) {
        __no_operation();                                                       // Placeholder for while loop (not required)
    }
}
