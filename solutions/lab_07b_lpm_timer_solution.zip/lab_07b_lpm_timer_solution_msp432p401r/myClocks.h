/*
 * myClocks.h
 *
 */

#ifndef MYCLOCKS_H_
#define MYCLOCKS_H_

//***** Prototypes ************************************************************
void initClocks(void);

//***** Defines ***************************************************************
#define LFXT_CRYSTAL_FREQUENCY_IN_HZ        32768                              // Freq of external crystal
#define HFXT_CRYSTAL_FREQUENCY_IN_HZ     48000000                              // Freq of external crystal

#define DCO_FREQUENCY_IN_HZ               6000000                              // We set DCO to this freq within this file
#define REFOCLK_FREQUENCY                 32768*4                              // We set DCO to this freq within this file 


#endif /* MYCLOCKS_H_ */

