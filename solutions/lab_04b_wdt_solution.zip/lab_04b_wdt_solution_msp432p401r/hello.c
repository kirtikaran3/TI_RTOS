// --------------------------------------------------------------------
// hello.c  (for lab_04b_wdt project) (MSP432)
// --------------------------------------------------------------------
#include <stdio.h>
#include <driverlib.h>

uint16_t count = 0;

int main(void) {
    WDTCTL = WDTPW | WDTHOLD;	                                        // Stop watchdog timer

    // Initialize the WDT as a watchdog
	MAP_WDT_A_initWatchdogTimer(
                             WDT_A_CLOCKSOURCE_ACLK,                    // Which clock should WDT use?
                             //WDT_A_CLOCKITERATIONS_64                 // WDT clock input divisor
							 WDT_A_CLOCKITERATIONS_512                  // -> Here are 4 (of 8) divisor choices
	                         //WDT_A_CLOCKITERATIONS_8192
                             //WDT_A_CLOCKITERATIONS_32K
	);

    // Start the watchdog
    WDT_A_start( WDT_A_BASE );

    while (1) {
    	//MAP_WDT_A_clearTimer();

        count++;
        printf( "I called this %d times\n", count );
    }
}

