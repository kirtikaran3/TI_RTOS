//***************************************************************************************
//  Hello world Example
//
//  Description: This simple program outputs hello world to the console
//
//  J. Stevenson
//  Texas Instruments, Inc
//  October 2008
//  Built with Code Composer Studio v4
//***************************************************************************************

#include <stdio.h>						// standard I/O needed for printf

void main(void) {
	printf("hello world\n");

	return;
}


